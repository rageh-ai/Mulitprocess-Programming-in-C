Compilation Instructions:

gcc -o A4 Assign04.c
